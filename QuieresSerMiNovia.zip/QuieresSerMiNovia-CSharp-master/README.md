# ¿Quieres ser mi novia?
Pequeño proyecto utilizando C# .NET Framework 4.7.2
## Recomendaciones:
Debes tener instalado Visual Studio Code, no importa la versión.
## Introducción:
Este proyecto tiene un panel principal donde se muestra la pregunta **¿Quieres Ser Mi Novia?**. Tendrás 2 opciones **"SÍ"**y**"NO"**.
Al pasar tu mouse por el botón NO este se moverá a otra posición random dejando sin posibilidad a la otra persona para darle click.

Al darle click al botón sí te saldrá otro pequeño panel con una respuesta y una imagen de un corazón que al darle click se cierra.